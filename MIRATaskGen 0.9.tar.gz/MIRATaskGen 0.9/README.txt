Date: April 2012
Name:MIRATaskGen
Version: 0.9 

Prerequisites:
----------------
 The software is written using python and wxpython. 
 
Installation in linux:
-------------- --------
 1) cd to MIRATaskGen 0.9 
 2) Type 'miratask' (without quotes) to start the software
 3) If any errors, cd to Source and type 'python MIRATaskGen.py' (without quotes)
 
 Working of the software
 ----------------------------
 1) Enter the number of actions and the title of the task analysis process
 2) Enter reason, instruction and goal for each action.
 3) Once all actions are entered, an option will be provided for the start and the end stage. Select `start' and `end' from the options.
 4) The parent screen will appear with the entered actions along with the GetSequence button. Press the GetSequence button.
 5) A sequence from the start to end appears on the screen.
 6) Click on File-->Save to save the input actions and the generated sequence.
 -----------------------------------------
 This software is constantly updated. 
 
