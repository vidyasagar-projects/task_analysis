
import pickle
import wx
import os
from wx.lib.masked import NumCtrl

class MyDialog(wx.Dialog):
    tot_action = [ ] 
    reason = [ ]
    dict = { }
    def __init__(self, parent, id, title):
        global num,rsnum, sw, n,acrs,test,k, rnum
        
        n += 1
       #k += 1
        rnum = num + 1
        dialog1 = wx.Dialog.__init__(self, parent, id, title, size=(900,700))        
        fontmira = wx.Font(16,wx.SWISS, wx.NORMAL, wx.BOLD)
        aclbl = "Action "+str(n)+"/"+str(num)
        self.wd = wx.StaticText(self, label = aclbl, pos = (40,30))
        #-------------------------------------------------------------------
        self.reason1 = wx.StaticText(self, label="New Reason:", pos=(20,90))        
        self.txtreason1 =  wx.TextCtrl(self, value = " ", pos=(120, 90), size=(380, -1))        
        
        self.listBox1 = wx.ListBox(choices=MyDialog.reason, id=7,
              name='listBox1', parent=self, pos=wx.Point(230, 140),
              size=wx.Size(250, 256), style=0)
        self.ins = wx.StaticText(self, label = "Instruction", pos = (350, 450))
        self.textins = wx.TextCtrl(self, value = " ", pos = (270,470), size = (250, -1))
        self.goal = wx.StaticText(self, label = "Goal", pos = (660, 450))
        self.textgoal = wx.TextCtrl(self, value = " ", pos = (560,470), size = (250, -1))
        self.lblrsn = wx.StaticText (self, label = "Reason", pos = (95,430))
        self.listBox2 = wx.ListBox(choices= [ ], id=8,
              name='listBox2', parent=self, pos=wx.Point(40, 450),
              size=wx.Size(184, 100), style=0)      
        #-------------------------------------------------------------------        
        self.btnok = wx.Button(self, 3, 'OK', (320,580), (50,-1)) 
        self.btnnext = wx.Button(self, 4, 'Next', (630,580), (50,-1))
        self.btnselect = wx.Button(self, 5, 'Select Reason', (530,200), (120,-1))
        self.btngoal = wx.Button (self, 13, 'Select Goal', (530, 260), (120,-1))
        self.btnremove = wx.Button (self, 14, 'Remove selection', (55,555), (150,-1))
        self.btnenter = wx.Button(self, 6, 'Enter', (500, 90), (60,-1))
        self.Bind (wx.EVT_BUTTON, self.OnAction, id=3)        
        self.Bind (wx.EVT_BUTTON, self.OnNext, id=4)
        self.Bind (wx.EVT_BUTTON, self.OnReason, id =5)
        self.Bind (wx.EVT_BUTTON, self.OnEnter, id = 6)
        self.Bind (wx.EVT_BUTTON, self.OnGoal, id = 13)
        self.Bind (wx.EVT_BUTTON, self.OnRemove, id = 14)
        #self.listBox1.Bind(wx.EVT_LISTBOX, self.OnListBox1Listbox,
        #      id=6)
        
    def OnEnter (self, event):
        global rnum
        reason = self.txtreason1.GetValue()   
        if reason == " ":
            rsndlg = wx.MessageDialog(None, "Enter the reason")
            rsndlg.ShowModal ()      
        rsn = 'r_'+str(rnum)
        MyDialog.dict[reason] = rsn
        rnum += 1
        self.listBox2.Append(reason)                       
        
    def OnReason (self, event):
        r = self.listBox1.GetStringSelection()         
        if r == "":
            selectrsndlg = wx.MessageDialog(None, "Select the proper text")
            selectrsndlg.ShowModal ()       
        self.listBox2.Append(r)
        
    def OnGoal (self, event):
        g = self.listBox1.GetStringSelection ()
        self.textgoal.SetValue(g)
        
    def OnRemove (self,event):
        remove = self.listBox2.GetSelection ()
        self.listBox2.Delete(remove)
        
         
    def OnAction (self, event):
        global k
        action = [ ]
        rs = self.listBox2.GetStrings ()                       
        ins = self.textins.GetValue ()
        if (ins == " "):
            insdlg = wx.MessageDialog(None, 'Enter the instruction')
            insdlg.ShowModal ()
        goal = self.textgoal.GetValue ()   
        if (goal == " "):
            goaldlg = wx.MessageDialog(None, 'Enter the goal')
            goaldlg.ShowModal () 
        rs+= [goal]        
        MyDialog.reason += rs            
        insvariable = 'i_' + str(n)
        goalvariable = 'p_'+str(n)
        MyDialog.dict[ins] = insvariable
        MyDialog.dict[goal] = goalvariable
        rsonly = self.listBox2.GetStrings () # Get only reason
        action = [rsonly] + [[ins]]+[[goal]]
            #print MyDialog.dict
            #print action       
        MyDialog.tot_action.append(action)
            #print action
        
    def OnNext (self,event):
        global n
        if n< num:
            self.wd.SetLabel(" ")
            aclbl = "Action "+str(n+1)+"/"+str(num)
            self.wd = wx.StaticText(self, label = aclbl, pos = (40,30))
            self.listBox1.Clear ()
            MyDialog.reason = list(set(MyDialog.reason))
            for rg in MyDialog.reason:                
                self.listBox1.Append(rg)            
            self.txtreason1.SetValue("")                  
            self.textins.SetValue("")              
            self.textgoal.SetValue("")   
            self.listBox2.Clear()  
                    
            n += 1
        else:
            #----------------------------------------------
            # Prints out action variables from the dictionary of actions           
            print MyDialog.dict
            print MyDialog.tot_action            
            actionvar = [ ]
            for ac in MyDialog.tot_action:
                # Picks up only reasons
                reason = [ ]
                for i in ac[0]:
                    reason += [MyDialog.dict[i]]
                    #print reason
                    #----------------------
                instruction = [MyDialog.dict[ac[1][0]]]
                goal = [MyDialog.dict[ac[2][0]]]
                actvariable = [reason]+[instruction]+[goal]
                print actvariable
                actionvar += [actvariable]
            print "action variable", actionvar
            #---------------------------------------------
            # Dump the input actions to the file - input
            inputfile = open("input.p", "wb")
            pickle.dump (MyDialog.tot_action,inputfile)
            inputfile.close ()
            #---------------------------------------------
            # If goal (p) is found in reason (r), then this chunk replaces 
            # 'p' with 'r'            
            actvupdated = [ ]
            for ac in  actionvar:
            #print len(ac[0]),ac[0]   
                rs = [ ] 
                for i,r in enumerate(ac[0]):
                #print r
                    if r.startswith('p'):        
                    #print "true"
                        reason = ac[0][i].replace ('p','r')
                    else:
                        reason = ac[0][i] 
                    rs += [reason]
                print rs
                ins = ac[1]
                goal = ac[2]
                actvchanged = [rs] + [ins] + [goal]   
                actvupdated += [actvchanged]
            print actvupdated

            #------------------------------------------------
            
              
            f1 = open("action.p", "wb")
            pickle.dump (actvupdated,f1)
            f1.close ()           
           
            self.listBox1.Clear ()
            MyDialog.reason = list(set(MyDialog.reason))
            for rg in MyDialog.reason:                
                self.listBox1.Append(rg)
            dlg = wx.MessageDialog(None, 'End of Actions')
            self.ins.Hide ()
            self.goal.Hide ()
            self.wd.Hide ()
            self.lblrsn.Hide ()            
            self.reason1.Hide ()
            self.txtreason1.Hide ()             
            self.btnenter.Hide ()
            self.btnselect.Hide ()                 
            self.textins.Hide ()              
            self.textgoal.Hide ()
            self.listBox2.Hide()   
            self.btnnext.Hide ()
            self.btnok.Hide ()   
            self.btngoal.Hide ()
            self.btnremove.Hide ()
            self.listBox3 = wx.ListBox(choices= [ ], id=8,
              name='listBox3', parent=self, pos=wx.Point(40, 450),
              size=wx.Size(184, 100), style=0)
            
            wx.StaticText(self, label = "Select start and End by clicking on the appropriate button", pos = (40,30))
            self.lblrsn = wx.StaticText (self, label = "Start", pos = (95,430))
            self.btnstart = wx.Button(self, 9, 'Start', (550,220), (80,-1))
            self.btnend = wx.Button(self, 10, 'End', (550, 300), (80,-1))
            self.end = wx.StaticText(self, label = "End", pos = (570, 445))
            self.textend = wx.TextCtrl(self, value = " ", pos = (470,470), size = (250, -1))
            #self.txtstart =  wx.TextCtrl(self, value = " ", pos = (70,450), size = (250, -1))
            #self.textend = wx.TextCtrl(self, value = " ", pos = (150,450), size = (250, -1))
            self.btnstartend = wx.Button(self, 11, 'OK', (90,580), (80,-1))
            self.btnclose = wx.Button(self, 12, 'Close', (580,580), (80,-1))
            self.Bind (wx.EVT_BUTTON, self.OnStart, id=9)        
            self.Bind (wx.EVT_BUTTON, self.OnEnd, id=10)
            self.Bind (wx.EVT_BUTTON, self.GetStartEnd, id = 11)
            self.Bind (wx.EVT_BUTTON, self.OnClose, id =12)
            dlg.ShowModal()
            
            #dlg.Destroy()  
            #self.Close () 
    
    def OnStart (self,event):
        start = self.listBox1.GetStringSelection ()
        self.listBox3.Append(start)
                
    def OnEnd (self,event):
        end = self.listBox1.GetStringSelection ()
        self.textend.SetValue(end)
        #print "End", MyDialog.dict[end]
    
    def GetStartEnd (self,event):
        global start, end
        #frame = self.GetParent ()
        #start = [str(self.textstart.GetValue ())]
        #end = [str(self.textend.GetValue ())]
        fontmira = wx.Font(16,wx.SWISS, wx.NORMAL, wx.BOLD)
        start = self.listBox3.GetStrings ()
        print "start", start
        end = self.textend.GetValue ()        
        f2 = open("se.p", "wb")
        se = [ ]
        for st in start:
            se = se+[MyDialog.dict[st]]
        print "start variable", se
        #se += [MyDialog.dict[start]]
        sen = [se] + [MyDialog.dict[end]]
        print "end variable", sen
        pickle.dump (sen,f2)
        f2.close ()
        print se
        frame = self.GetParent ()
        y = 300
        i = 1
        
        for l in MyDialog.tot_action: 
             act = "Action" + str(i)+ ":"
             self.actlabel = wx.StaticText(frame.scroll, label = act, pos = (20,y))
             self.actins =wx.StaticText(frame.scroll, label = str(l[1][0]), pos = (120,y))
             self.actlabel.SetFont(fontmira)
             self.actins.SetFont (fontmira)
             i += 1
             y += 50
        wx.Button(frame.scroll, 4, 'Get Sequence', (50,y), (120,-1))
        frame.scroll.SetScrollbars(0,y,0,y/55)
        frame.scroll.SetScrollRate(1,1)
        frame.testdict = MyDialog.dict
        frame.testaction = MyDialog.tot_action
        frame.Bind (wx.EVT_BUTTON, frame.GetSequence, id=4) 
        
      
    
    
    def OnClose (self, event):
        self.Close ()
        

class MainWindow(wx.Frame):
    def __init__(self, parent, title):
        global n , testdict, testaction
        #global num        
        self.dirname = ' '
        #n = 0    
        self.testdict = { }    
        self.testaction = [ ]
        top = wx.Frame.__init__(self, parent, title=title, size=(700,800))
        self.frame = parent
        self.ypos = 180        
        self.CreateStatusBar()
        self.scroll=wx.PyScrolledWindow(self, -1)
        self.scroll.SetBackgroundColour("WHEAT")
        #pic = wx.Icon("logo.ico", wx.BITMAP_TYPE_ICO)
        #self.SetIcon(pic)
        #----------------------------------------------------
        
        
        # Setting up the menu.
        filemenu= wx.Menu()
        menuSave = filemenu.Append(wx.ID_SAVE, "&Save"," Save the actions and the sequence to a text file")
        menuAbout= filemenu.Append(wx.ID_ABOUT, "&About"," Information about this program")
        menuExit = filemenu.Append(wx.ID_EXIT,"E&xit"," Terminate the program")
        
      # Creating the menubar.
        menuBar = wx.MenuBar()
        menuBar.Append(filemenu,"&File") # Adding the "filemenu" to the MenuBar
        self.SetMenuBar(menuBar)  # Adding the MenuBar to the Frame content.
        
        self.title = wx.StaticText(self.scroll, label="Task Facilitator using MIRA", pos=(105,20))
        self.title.SetForegroundColour("FOREST GREEN")
        font1 = wx.Font(18, wx.MODERN, wx.NORMAL, wx.BOLD)
        fontmira = wx.Font(16,wx.SWISS, wx.NORMAL, wx.BOLD)
        self.title.SetFont(font1)
        self.lbl_num_actions = wx.StaticText(self.scroll, label="Number of actions :", pos=(20,90))
        self.lbl_num_actions.SetFont(fontmira)
        #self.num_actions = wx.lib.masked.NumCtrl(self, pos = (160,90), size = (50,-1),style = wx.RA_SPECIFY_COLS)
        num = 1
        self.edit = wx.TextCtrl(self.scroll, value = str(num), pos=(260, 90), size=(50, -1))
        
        # respond to enter key when focus is on edit
        
        #self.edit.Bind(wx.EVT_TEXT_ENTER, self.onAction)
        self.edit.SetFocus()
        self.stitle = wx.StaticText(self.scroll, label = "Title: ", pos = (20,130))
        self.stitle.SetFont(fontmira)
        self.title = wx.TextCtrl(self.scroll, value = " ", pos = (100, 130), size = (250, -1))
        
        wx.Button(self.scroll, 1, 'Enter', (40, 170))
        self.Bind (wx.EVT_BUTTON, self.OnShowCustomDialog, id=1)        
        
        
        #self.num_actions = wx.TextCtrl(self, value="50", pos=(160, 90), size=(50,-1),style = wx.TE_PROCESS_ENTER)
        #self.Bind(wx.EVT_TEXT, self.EvtText1, self.num_actions)       
                                                                                                                                                                     
        
        
        # Events.
        self.Bind(wx.EVT_MENU, self.OnSave, menuSave)
        self.Bind(wx.EVT_MENU, self.OnExit, menuExit)
        self.Bind(wx.EVT_MENU, self.OnAbout, menuAbout)
        self.Show (True)    

    
    
     
    def OnAbout(self,e):
        # Create a message dialog box
        description = """MIRATaskGen is developed using MIRA, inspired by the Indian Philosophical system Mimamsa
"""

        licence = """MIRATaskGen is a free software; you can redistribute 
it and/or modify it under the terms of the GNU General Public License as 
published by the Free Software Foundation; either version 2 of the License, 
or (at your option) any later version.

MIRATaskGen is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
See the GNU General Public License for more details. You should have 
received a copy of the GNU General Public License along with MIRATaskGen; 
if not, see <http://www.gnu.org/licenses/>"""


        info = wx.AboutDialogInfo()

        info.SetIcon(wx.Icon('logo.png', wx.BITMAP_TYPE_PNG))
        info.SetName('MIRATaskGen')
        info.SetVersion('0.9')
        info.SetDescription(description)
        #info.SetCopyright('(C) 2012 Bama Srinivasan')
        #info.SetWebSite('http://www.zetcode.com')
        info.SetLicence(licence)
        info.AddDeveloper('Bama Srinivasan')
        info.AddDeveloper('Ranjani Parthasarathi')
        #info.AddDocWriter('Jan Bodnar')
        #info.AddArtist('The Tango crew')
        #info.AddTranslator('Jan Bodnar')
        wx.AboutBox(info)        

    def OnExit(self,e):
        self.Close(True)  # Close the frame.

    def OnSave(self,e):
        """ Open a file"""
        # Save away the edited text
        # Open the file, do an RU sure check for an overwrite!
        dlg = wx.FileDialog(self, "Choose a file", self.dirname, "", "*.*", \
                wx.SAVE | wx.OVERWRITE_PROMPT)
        if dlg.ShowModal() == wx.ID_OK:
            # Grab the content to be saved
            title = self.title.GetValue ()

            # Open the file for write, write, close
            self.filename=dlg.GetFilename()
            self.dirname=dlg.GetDirectory()
            filehandle=open(os.path.join(self.dirname, self.filename),'w')
            filehandle.write(title)
            filehandle.write("\n")
            filehandle.write ("---------------------")
            filehandle.write ("\n")                 
            filehandle.write("Input actions")
            filehandle.write ("\n")
            filehandle.write("----------------")         
            filehandle.write ("\n")
            from genlist5 import combinedsequence,success,seqatstep
            inputaction = pickle.load(open("input.p","rb"))
            filehandle.write ("\n")
            i = 0
            for inp in inputaction:
                i += 1
                actnum = "Action "+ str(i)
                filehandle.write(actnum)
                filehandle.write ("\n")
                filehandle.write("--------")    
                filehandle.write ("\n")
                filehandle.write("Reason: ")    
                for rs in inp[0]:
                    filehandle.write (rs)
                    filehandle.write (", ")        
                filehandle.write ("\n")
                filehandle.write ("Instruction: ")
                filehandle.write (inp[1][0])
                filehandle.write ("\n")
                filehandle.write ("Goal: ")
                filehandle.write (inp[2][0])
                filehandle.write ("\n")        
            filehandle.write ("\n")
            filehandle.write ("Start: ")
            for st in start:
                filehandle.write (st),
                filehandle.write (", "), 
            filehandle.write ("\n")
            filehandle.write ("End: ")
            filehandle.write (end)
            filehandle.write ("\n")
            filehandle.write ("\n")
            filehandle.write("Sequence generated")
            filehandle.write ("\n")
            filehandle.write("------------------")
            filehandle.write ("\n")
            stepn = 0      
            for instruction in seqatstep:
                stepn += 1
                step = "Step" + str(stepn)                
                filehandle.write (step)
                filehandle.write ("\n")
                
                for ins in instruction:
                    givenins = [givenins for givenins, value in self.testdict.iteritems () if value == ins][0] 
                    #nin += 1
                    #task = "Task: "
                    generateins = givenins  
                    filehandle.write(generateins)
                    filehandle.write ("\n")
            filehandle.write ("\n")
            filehandle.write (success)
            filehandle.write ("\n")
            
            filehandle.close()
        # Get rid of the dialog to keep things tidy
        dlg.Destroy()
       
    def onAction(self, event):  
        global num, rnum, title      
        num = int(self.edit.GetValue().strip())
        title = self.title.GetValue()
        
    def OnShowCustomDialog(self, event):        
        global n, num, dia
        n = 0
        num = int(self.edit.GetValue().strip())
        dia = MyDialog(self, -1, 'Action details input')        
        dia.ShowModal()
        dia.Destroy()
        
    def GetSequence (self, event):
            global sampledict
            title = self.title.GetValue ()
            fontmira = wx.Font(16,wx.SWISS, wx.NORMAL, wx.BOLD)
            strtitle = title + ".txt"
            #f3 = open(strtitle, "wb") # Write to a file        
            #f3.write(title)
            #f3.write("\n")
            #f3.write ("---------------------")
            #f3.write ("\n")                 
            #f3.write("Input actions")
            #f3.write ("\n")
            #f3.write("----------------")         
            #f3.write ("\n")
            self.seq = wx.StaticText(frame.scroll, label = "Sequence" , pos = (500,200))
            font2 = wx.Font(16, wx.MODERN, wx.NORMAL, wx.BOLD)
            self.seq.SetFont(fontmira)
            from genlist5 import combinedsequence,success,seqatstep
            y2 = 250
            print self.testdict    
            #Write the input actions to the file
            #inputaction = pickle.load(open("input.p","rb"))
            #f3.write ("\n")
            #i = 0
            #for inp in inputaction:
            #    i += 1
            #    actnum = "Action "+ str(i)
                #f3.write(actnum)
                #f3.write ("\n")
                #f3.write("--------")    
                #f3.write ("\n")
                #f3.write("Reason: ")    
             #   for rs in inp[0]:
              #      f3.write (rs)
               #     f3.write (", ")        
                #f3.write ("\n")
                #f3.write ("Instruction: ")
                #f3.write (inp[1][0])
                #f3.write ("\n")
                #f3.write ("Goal: ")
                #f3.write (inp[2][0])
                #f3.write ("\n")        
            #f3.write ("\n")
            #--------------------------
            print success
            
            print combinedsequence
            print seqatstep            
            nin = 0
            #f3.write ("Start: ")          
            #Write the result to the file
            #for st in start:
            #    f3.write (st),
            #    f3.write (", "), 
            #f3.write ("\n")
            #f3.write ("End: ")
            #f3.write (end)
            #f3.write ("\n")
            #f3.write ("\n")
            #f3.write("Sequence generated")
            #f3.write ("\n")
            #f3.write("------------------")
            #f3.write ("\n")
            stepn = 0      
            for instruction in seqatstep:
                stepn += 1
                step = "Step" + str(stepn)
                self.step = wx.StaticText(frame.scroll, label = step, pos = (480,y2))
                self.step.SetForegroundColour (wx.BLUE)
                self.step.SetFont(fontmira)
                #f3.write (step)
                #f3.write ("\n")
                y2 += 30
                for ins in instruction:
                    givenins = [givenins for givenins, value in self.testdict.iteritems () if value == ins][0] 
                    #nin += 1
                    #task = "Task: "
                    generateins = givenins  
                    self.task = wx.StaticText(frame.scroll, label = generateins, pos= (480, y2))
                    self.task.SetForegroundColour ((139,69,19))
                    self.task.SetFont (fontmira)
                    y2 += 50
                    #f3.write(generateins)
                    #f3.write ("\n")
            #f3.write ("\n")
            #f3.write (success)
            #f3.write ("\n")
            #-----------------------------------------------
            self.succ = wx.StaticText (frame.scroll, label = success, pos = (480, y2))
            self.succ.SetFont(fontmira)
            #text.SetForegroundColour((255,0,0)) # set text color
            re = str(self.succ.GetLabel())
            if re == "Goal Reached":
                self.succ.SetFont(font2)
                self.succ.SetForegroundColour((0,100,0))
            else:
                self.succ.SetFont(font2)
                self.succ.SetForegroundColour(wx.RED)
            #f3.close()
                    

app = wx.App(False)
k = 0
frame = MainWindow(None, "MIRATaskGen")
app.MainLoop()
