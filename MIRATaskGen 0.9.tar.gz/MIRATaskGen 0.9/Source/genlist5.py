import pickle
from sets import Set

def common (ac,reason):
    global sequence, subgoal, replacegoal, step,memorysequence,combinedsequence
    #print ac
    acrsn = Set(ac[0])
    #print "acrsn",acrsn
    setreason = Set(reason)
    #print "setreason", setreason
    
    #---------------------------------------------------------
    #Modus ponens by intersection of two sets of action and reason
    commonrsn = list(acrsn.intersection(setreason))
    commonrsn.sort()# These two lines are needed, because the action may contain
    ac[0].sort()#action as r1 and r2 or r2 and r1. The program will loop for ever if these lines are not there     
    #print "common reason", commonrsn
    if commonrsn == ac[0]:
        #print "Action trigerred"
        sequence += ac[2]        
        subgoal += ac[4]
        goalasreason = ac[4][0].replace('p','r')
        replacegoal += [goalasreason]
    #-----------------------------------------------------

def indins(ac):
    global sequence, subgoal, replacegoal
    if ac[0][0].startswith('i_'):
        sequence += ac[0]
        subgoal += ac[2]
        goalasreason = ac[2][0].replace('p','r')
        replacegoal += [goalasreason]        

def extractind():
    global step,sequence, subgoal, memorysequence,seqatstep
    combinedsequence = [ ]
    seqatstep = [ ]
    for ac in action:
        indins(ac)
    print "Step", step
    print "-----------"
    print "Memory sequence", memorysequence  #Earlier sequence
    print "Full Sequence", list(set(sequence))
#------------------------------------------------------------------- 
   #Get only sequence for this step
    for item in memorysequence:
        if item in list(set(sequence)):
            sequence.remove(item)
    print "The sequence in this step", sequence
    #print "To get only sequence", [sequence]
#--------------------------------------------------------------------
    combinedsequence += sequence
    #seqatstep += [list(set(sequence))]
    memorysequence += list(set(sequence))
    print "Subgoal", list(set(subgoal))
    print "Goal as reason", list(set(replacegoal))        
def kb(reason):
    global sequence, subgoal, replacegoal, step,memorysequence, combinedsequence, previous_goal,success,seqatstep  
    for ac in action:        
        common (ac,reason)
    step += 1
    print "Step", step 
    print "---------"
    print "Memory sequence", memorysequence  #Earlier sequence
    print "Full Sequence", list(set(sequence))
#------------------------------------------------------------------- 
   #Get only sequence for this step
    for item in memorysequence:
        if item in list(set(sequence)):
            sequence.remove(item)
    print "The sequence in this step", list(set(sequence))
    #print "To get only sequence", [list(set(sequence))]
#--------------------------------------------------------------------
    combinedsequence = combinedsequence + sequence
    seqatstep += [list(set(sequence))]
    memorysequence += list(set(sequence))
    print "Subgoal", list(set(subgoal))
    print "Goal as reason", list(set(replacegoal))    
    if set(goal).issubset(Set(subgoal)):
        success = "Goal Reached"
        print success
        print "combined sequence", combinedsequence
        print "sequence at each step", seqatstep  
        print "number of steps", len(seqatstep)
        for step in range (0,len(seqatstep)):
            print "step :", step+1, seqatstep[step]
    else:
        if previous_goal == list(set(subgoal)):
            print "Last step goal", previous_goal
            print "This step goal", subgoal		
            success = "Goal Not Reached"
            print success
            print "Combined Sequence", combinedsequence
        else:
            previous_goal = list(set(subgoal))
            sequence = [ ]
            subgoal = [ ]
            reason = list(set(reason+replacegoal)) 
            #print "reason", reason       
            kb(reason)
    
action = pickle.load(open("action.p","rb"))
print len(action)

act = [ ]
for i in action:
    i.insert (1,['implr'])
    i.insert (3,['implp'])
    print i
sten = pickle.load (open("se.p","rb"))
print "start and end", sten
initial = sten[0]
print "initial", initial
reason = sten[0]
goal = [sten[1]]
print "goal", goal 
sequence = [ ]
combinedsequence = [ ]
memorysequence = [ ]
subgoal = [ ]
previous_goal = [ ]
replacegoal = [ ]
step = 1
extractind()
kb(reason)
